//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"


@implementation Orders

@end

@implementation Passenger

- (void)bookTicket {
    Orders *ticket = [Orders init];
    [self.his addObject:(Orders *) ticket];
    [self.unChecked addObject:(Orders *) ticket];
}

- (BOOL)checkTicket:(NSInteger *)ticketId {
    Orders *ticket;
    for (ticket in _unChecked) {
        if (ticket.id == ticketId) {
            ticket.ifChecked = YES;
            [self.unChecked removeObject:ticket];
            return YES;
        }
    }
    return NO;
}

@end
